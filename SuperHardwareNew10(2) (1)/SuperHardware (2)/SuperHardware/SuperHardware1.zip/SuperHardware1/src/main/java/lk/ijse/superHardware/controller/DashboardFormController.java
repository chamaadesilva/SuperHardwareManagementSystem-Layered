package lk.ijse.superHardware.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class DashboardFormController {
    @FXML
    void btnOnActionCustomer(ActionEvent event) {

    }

    @FXML
    void btnOnActionDashboard(ActionEvent event) {

    }

    @FXML
    void btnOnActionDelivery(ActionEvent event) {

    }

    @FXML
    void btnOnActionEmployee(ActionEvent event) {

    }

    @FXML
    void btnOnActionFullReport(ActionEvent event) {

    }

    @FXML
    void btnOnActionItemStoDet(ActionEvent event) {

    }

    @FXML
    void btnOnActionItemStock(ActionEvent event) {

    }

    @FXML
    void btnOnActionOrder(ActionEvent event) {

    }

    @FXML
    void btnOnActionOrderItemDetails(ActionEvent event) {

    }

    @FXML
    void btnOnActionSupplier(ActionEvent event) {

    }

    @FXML
    void btnOnActionSupplierOrder(ActionEvent event) {

    }
}
