package lk.ijse.superHardware.dto;




public class OrderItemDetailsDto {

}
