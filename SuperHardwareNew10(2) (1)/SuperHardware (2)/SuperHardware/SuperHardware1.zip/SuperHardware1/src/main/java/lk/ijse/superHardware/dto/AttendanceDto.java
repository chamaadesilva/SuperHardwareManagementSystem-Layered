package lk.ijse.superHardware.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Time;
import java.util.Date;


public class AttendanceDto {
    private String attendanceId;
    private String employeeId;
    private Date date;
    private Time time;

    public AttendanceDto() {
    }

    public AttendanceDto (String attendanceId,String employeeId,Date date,Time time) {
        this.attendanceId = attendanceId;
        this.employeeId = employeeId;
        this.date = date;
        this.time = time;
    }

    public String getAttendanceId(){
        return attendanceId;
    }
    public void setAttendanceId(String attendanceId){
        this.attendanceId =attendanceId;
    }
    public String getEmployeeIdeId(){

        return employeeId;
    }
    public void setEmployeeId(String attendanceId){
        this.employeeId =employeeId;
    }

    public Date getDate(){
        return date;
    }

    public void setDate(Date date){
        this.date = date;
    }
}
