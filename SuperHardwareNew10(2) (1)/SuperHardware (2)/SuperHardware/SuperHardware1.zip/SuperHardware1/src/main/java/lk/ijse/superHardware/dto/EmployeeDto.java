package lk.ijse.superHardware.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


public class EmployeeDto {
    private String employeeId;

    private String employeename;

    private String address;

    public EmployeeDto() {
    }

    public EmployeeDto(String employeeId,String employeename,String address) {
        this.employeeId = employeeId;
        this.employeename = employeename;
        this.address = address;

    }

    public String getEmployeeId() {

        return employeeId;
    }
    public void setEmployeeId(String employeeId){
        this.employeeId = employeeId;
    }

    public String getEmployeename(){

        return employeename;
    }

    public void setEmployeename(String employeename){
        this.employeename = employeename;
    }

    public String getaddress() {
        return address;
    }
    public void setAddress(String address){
        this.address = address;
    }
}
