package model;

import lk.ijse.superHardware.dto.CustomerDto;

public class CustomerModel {
    public boolean updateCustomer(CustomerDto dto) {
    }
}
