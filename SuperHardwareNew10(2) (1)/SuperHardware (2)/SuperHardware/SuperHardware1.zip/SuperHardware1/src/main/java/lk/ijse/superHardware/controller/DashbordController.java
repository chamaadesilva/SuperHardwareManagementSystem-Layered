package lk.ijse.superHardware.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.io.IOException;

public class DashbordController {

    @FXML
    private AnchorPane root;
    @FXML
    void btnOnActionCustomer(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/CustomerFormController.fxml"));
        Pane ui = fxmlLoader.load();

        root.getChildren().clear();
        root.getChildren().setAll(ui);
    }

    @FXML
    void btnOnActionDashboard(ActionEvent event) {

    }

    @FXML
    void btnOnActionDelivery(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/DeliveryFormController.fxml"));
        Pane ui = fxmlLoader.load();

        root.getChildren().clear();
        root.getChildren().setAll(ui);
    }

    @FXML
    void btnOnActionEmployee(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/EmployeeFormController.fxml"));
        Pane ui = fxmlLoader.load();

        root.getChildren().clear();
        root.getChildren().setAll(ui);
    }

    @FXML
    void btnOnActionFullReport(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/"));
        Pane ui = fxmlLoader.load();

        root.getChildren().clear();
        root.getChildren().setAll(ui);
    }

    @FXML
    void btnOnActionItemStoDet(ActionEvent event) {

    }

    @FXML
    void btnOnActionItemStock(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/ItemStockFormController.fxml"));
        Pane ui = fxmlLoader.load();

        root.getChildren().clear();
        root.getChildren().setAll(ui);
    }

    @FXML
    void btnOnActionOrder(ActionEvent event) {

//        dan navigate wenwa ne crud eka ghagnn puluwanda ?ekk ghnnko puluwannm
//        save ekk ghannm ha ehnm

    }

    @FXML
    void btnOnActionOrderItemDetails(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/OrderItemDetailsFormController.fxml"));
        Pane ui = fxmlLoader.load();

        root.getChildren().clear();
        root.getChildren().setAll(ui);
    }

    @FXML
    void btnOnActionSupplier(ActionEvent event) {

    }

    @FXML
    void btnOnActionSupplierOrder(ActionEvent event) {

    }

}
