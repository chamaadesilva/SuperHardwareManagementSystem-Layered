package lk.ijse.superHardware.dto;


public class CustomerDto {
    private String customerId;
    private String customername;
    private String address;
    private int contact;


    public CustomerDto(String customerId, String customerName, String address, String contact){
    }

    public CustomerDto(String customerId,String customername,String address,int contact){
        this. customerId = customerId;
        this.customername = customername;
        this.address = address;
        this.contact = contact;
    }

    public String getCustomerId() {
        return customerId;
    }


    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public void setCustomername(String customername) {

        this.customername = customername;
    }
    public String getCustomername(){
        return customername;
    }
    public String getAddress(){

        return address;
    }
    public void setAddress(String address){

        this.address = address;
    }

    public int getContact(){
        return contact;
    }

    public void setContact(int contact){
        this.contact = contact;
    }

    }

