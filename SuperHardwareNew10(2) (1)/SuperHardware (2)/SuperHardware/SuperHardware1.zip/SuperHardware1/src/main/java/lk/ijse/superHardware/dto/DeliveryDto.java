package lk.ijse.superHardware.dto;


import java.security.PrivateKey;

public class DeliveryDto {
    private String deliveryId;
    private String orderId;
    private String employeeId;
    private String location;


    public DeliveryDto(){

    }


    public DeliveryDto(String deliveryId,String orderId,String employeeId,String location){
        this.deliveryId = deliveryId;
        this.orderId = orderId;
        this.employeeId = employeeId;
        this.location = location;
    }

    public String getDeliveryId() {

        return deliveryId;
    }

    public void setDeliveryId(String deliveryId) {
        this.deliveryId = deliveryId;
    }

    public String getEmployeeId(){

        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }
    public String getOrderId(){

        return orderId;
    }

    public void setOrderId(String orderId) {

        this.orderId = orderId;
    }
    public String getLocation(){
        return location;
    }
    public void setLocation(String location){
        this.location = location;
    }
}
