package lk.ijse.superHardware.dto;


import java.util.Date;

public class SalaryDto {
    private String salaryId;
    private String employeeId;
    private Double salaryamount;
    private Date date;

    public SalaryDto(){
    }
    public SalaryDto(String salaryId,String employeeId,Double salaryamount,Date date){
        this.salaryId = salaryId;
        this.employeeId = employeeId;
        this.salaryamount = salaryamount;
        this.date = date;
    }
}
