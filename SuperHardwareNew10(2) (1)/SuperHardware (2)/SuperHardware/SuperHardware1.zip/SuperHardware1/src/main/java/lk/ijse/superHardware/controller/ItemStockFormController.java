package lk.ijse.superHardware.controller;

import javafx.event.ActionEvent;

public class ItemStockFormController {
    public void btnOnActionDashboard(ActionEvent actionEvent) {
    }
}
