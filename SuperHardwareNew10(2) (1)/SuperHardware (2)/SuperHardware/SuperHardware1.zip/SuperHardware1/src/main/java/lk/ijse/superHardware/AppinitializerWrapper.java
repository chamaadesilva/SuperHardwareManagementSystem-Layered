package lk.ijse.superHardware;

public class AppinitializerWrapper{
    public static void main(String[] args) {
        AppInitializer.main(args);
    }
}
