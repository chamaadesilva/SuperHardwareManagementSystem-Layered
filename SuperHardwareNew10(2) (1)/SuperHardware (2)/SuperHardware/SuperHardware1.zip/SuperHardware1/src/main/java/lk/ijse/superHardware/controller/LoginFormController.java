package lk.ijse.superHardware.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

    public class LoginFormController {

        @FXML
        private Button btnLogin;

        @FXML
        private AnchorPane loginPane;

        private String UserName="chamaa";
        private String Password= "1234";
    private TextField txtPassword;

    @FXML
    private TextField txtUserName;

    @FXML
    void btnLoginOnAction(ActionEvent event) throws IOException {
//        System.out.printf("sample");

            if (UserName.equals(txtUserName.getText()) && Password.equals(txtPassword.getText())){
                Parent root=FXMLLoader.load(this.getClass().getResource("/view/DashboardFormController.fxml"));
               // Parent root = FXMLLoader.load(this.getClass().getResource("/view/DashBoardFormController.fxml"));
                Scene scene=new Scene(root);
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();

                Stage stage1 = (Stage) loginPane.getScene().getWindow();
                stage1.close();

            }else{
                new Alert(Alert.AlertType.ERROR,"login information are incorrect");
            }
        }



    @FXML
    void txtPasswordOnAction(ActionEvent event) {

    }

    @FXML
    void txtUserNameOnAction(ActionEvent event) {

    }

}
