package lk.ijse.superHardware.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


public class ItemStockDto {
    private String itemStockCode;

    private String itemName;

    private String quantity;

    private double itemUnitPrice;

    private String itemCateogry;

    public ItemStockDto(){

    }
public ItemStockDto(String itemStockCode,String itemName,String quantity,double itemUnitPrice,
                    String itemCateogry){
        this.itemStockCode = itemStockCode;
        this.itemName = itemName;
        this.quantity = quantity;
        this.itemUnitPrice = itemUnitPrice;
        this.itemCateogry = itemCateogry;
}

    public String getItemStockCode(){
        return itemStockCode;

}
   public void setItemStockCode(String itemStockCode){
        this.itemStockCode = itemStockCode;
}

  public String getItemName(){
        return itemName;
}

  public void setItemName(String itemName){
        this.itemName = itemName;
}
   public String getQuantity(){
        return quantity;
   }

   public void setQuantity(String quantity){
        this.quantity = quantity;
   }
   public double getItemUnitPrice(){
        return itemUnitPrice;
   }
   public void setItemUnitPrice(String itemUnitPrice){
        this.itemUnitPrice = Double.parseDouble(itemUnitPrice);
   }
   public String getItemCateogry(){
        return itemCateogry;
   }
   public void setItemCateogry(String itemCateogry){
        this.itemCateogry = itemCateogry;
   }

}



