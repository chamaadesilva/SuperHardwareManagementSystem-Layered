package lk.ijse.superHardware.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import lk.ijse.superHardware.db.DbConnection;
import lk.ijse.superHardware.dto.CustomerDto;
import model.CustomerModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CustomerFormController {

    @FXML
    private TextField txtAddress;

    @FXML
    private TextField txtContact;

    @FXML
    private TextField txtId;

    @FXML
    private TextField txtName;

    public void btnOnActionDashboard(ActionEvent actionEvent) {
    }

    public void btnSaveOnAction(ActionEvent actionEvent) {
        try {
            Connection connection = DbConnection.getInstance().getConnection();
            PreparedStatement pstm = connection.prepareStatement("insert into customer values(?,?,?,?)");//quary eka ghnna
            pstm.setString(1, txtId.getText());
            pstm.setString(2, txtName.getText());
            pstm.setString(3, txtAddress.getText());
            pstm.setDouble(4, Double.parseDouble(txtContact.getText()));

            int affectedRows = pstm.executeUpdate();

            System.out.println(affectedRows);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void btnOnActionUpdate(ActionEvent event) {
        String customerId = txtId.getText();
        String customerName = txtName.getText();
        String address = txtAddress.getText();
        String contact = txtContact.getText();

        var dto = new CustomerDto(customerId,customerName,address,contact);
var model = new  CustomerModel();
try{
    boolean isUpdated = model.updateCustomer(dto);
    System.out.print(isUpdated);
    if(isUpdated){
        new Alert(Alert.AlertType.CONFIRMATION,"customer update!").show();
    }

}catch (SQLException e){
    new Alert(Alert.AlertType.ERROR, e.getMessage()).show();

        }
    }


}






