package lk.ijse.superHardware.controller;

import javafx.event.ActionEvent;

public class DeliveryFormController {
    public void btnOnActionDashboard(ActionEvent actionEvent) {
    }
}
